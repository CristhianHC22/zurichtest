# Proyecto de Microservicios con Docker Compose

Este proyecto utiliza Docker Compose para levantar un entorno de back que incluye servicios de bases de datos PostgreSQL y spring boot.

## Versiones
- Docker: 3.8
- PostgreSQL: 15

## Estructura del Proyecto

La estructura básica del proyecto incluye los siguientes servicios:

- **zurichdb**: Base de datos PostgreSQL para el servicio de clientes.
- **zurich-service**: Servicio que maneja la lógica e interactuar con la base de datos.

## Requisitos Previos

Asegúrate de tener instalados los siguientes requisitos antes de ejecutar el proyecto:

- [Docker](https://www.docker.com/get-started) 
- [Docker Compose](https://docs.docker.com/compose/)

## Configuración y Ejecución

1. **Clona el repositorio**:

   ```bash
   git clone https://CristhianHC93@bitbucket.org/CristhianHC93/spring-boot-microservices-kafka.git
   cd spring-boot-microservices-kafka

2. **Construye y levanta los servicios**:

Para construir las imágenes de los microservicios y levantar todos los servicios definidos en docker-compose.yml, ejecuta:

	docker-compose up --build

3. **Acceso a los servicios**:

Zurich Service: Accede en http://localhost:8080
Documentación de Zurich Service: Accede en http://localhost:8080/swagger-ui/index.html
PostgreSQL Zurich DB: Puerto 5432

Detalles de Configuración
Bases de Datos PostgreSQL
La bases de datos está configurada con un usuario y contraseña predeterminados (postgres).
Los datos se almacenan en volúmenes para garantizar la persistencia.

El usuario por defecto
user: admin
pass: admin123

Se adjunta archivo yaml de swagger 

Cada vez que el admin cree un cliente, este generara un usuario cuyo user y password sera el numero de identificación, este usuario se creara con ROL_CUSTOMER
