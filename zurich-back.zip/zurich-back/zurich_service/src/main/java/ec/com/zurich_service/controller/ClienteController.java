package ec.com.zurich_service.controller;

import ec.com.zurich_service.resource.dto.*;
import ec.com.zurich_service.resource.validation.PatchValidationGroup;
import ec.com.zurich_service.resource.validation.PostValidationGroup;
import ec.com.zurich_service.services.ClienteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jdk.jfr.Description;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Description("Gestion de clientes")
@RestController
@Tag(name = "Cliente")
@RequestMapping("/clientes")
@Slf4j
@AllArgsConstructor
public class ClienteController {

    private final ClienteService clienteService;

    @PreAuthorize("hasAnyRole('ADMIN')")
    @Operation(summary = "Registrar cliente", description = "Se registra un nueva cliente")
    @PostMapping
    public ResponseEntity<ClienteResponse> createCliente(@Validated(PostValidationGroup.class) @RequestBody ClienteRequest request) {
        return ResponseEntity.ok(clienteService.create(request));
    }

    @PreAuthorize("hasAnyRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<ClienteResponse> deleteCliente(@PathVariable Long id) {
        return ResponseEntity.ok(clienteService.delete(id));
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'CUSTOMER')")
    @PatchMapping("/{id}")
    public ResponseEntity<ClienteResponse> updateCliente(@PathVariable Long id, @Validated(PatchValidationGroup.class) @RequestBody ClienteRequest request) {
        return ResponseEntity.ok(clienteService.update(id, request));
    }

    @PreAuthorize("hasAnyRole('CUSTOMER')")
    @PutMapping("/usuario")
    public ResponseEntity<ClienteResponse> updateMyPoliza(HttpServletRequest requestHttp, @Validated(PatchValidationGroup.class) @RequestBody ClienteRequest request) {
        Long userId = (Long) requestHttp.getAttribute("userId");
        return ResponseEntity.ok(clienteService.updateSelf(userId, request));
    }


    @PreAuthorize("hasAnyRole('CUSTOMER')")
    @GetMapping("/usuario")
    public ResponseEntity<ClienteResponse> find(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        return ResponseEntity.ok(clienteService.findByMyUsuarioId(userId));
    }

    @PreAuthorize("hasAnyRole('ADMIN')")
    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE}, value = "")
    public ResponseEntity<ListDto<ClienteResponse>> findBy(@RequestParam(name = "nombre", required = false) String nombre,
                                                           @RequestParam(name = "email", required = false) String email,
                                                           @RequestParam(name = "identificacion", required = false) String identificacion,
                                                           @RequestParam(required = false, defaultValue = "0", name = "pagina") Integer pagina,
                                                           @RequestParam(required = false, defaultValue = "10", name = "limite") Integer limite) {

        return ResponseEntity.ok(clienteService.findBy(nombre, email, identificacion, pagina, limite));
    }
}
