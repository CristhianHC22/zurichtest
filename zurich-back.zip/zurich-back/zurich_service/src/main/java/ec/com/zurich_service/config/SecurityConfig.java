package ec.com.zurich_service.config;

import ec.com.zurich_service.services.CustomUserDetailsService;
import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

@Configuration
@AllArgsConstructor
@EnableMethodSecurity
public class SecurityConfig {

    private final CustomUserDetailsService userDetailsService;
    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
        return configuration.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll()
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll() // Permitir todas las solicitudes OPTIONS
                        .requestMatchers("/auth/login").permitAll() // Permitir el acceso al login sin autenticación
                        .requestMatchers("/clientes").hasAnyRole("ADMIN", "CUSTOMER")  // /clientes solo para ADMIN y CUSTOMER
                        .requestMatchers("/clientes/**").hasAnyRole("ADMIN", "CUSTOMER") // /clientes/{id} solo para ADMIN y CUSTOMER
                        .requestMatchers("/polizas").hasAnyRole("ADMIN", "CUSTOMER")  // /clientes solo para ADMIN y CUSTOMER
                        .requestMatchers("/polizas/**").hasAnyRole("ADMIN", "CUSTOMER") // /clientes/{id} solo para ADMIN y CUSTOMER
                        .anyRequest().authenticated()             // Requiere autenticación para el resto de las rutas
                )
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class) // Registrar el filtro
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.NEVER))
                .httpBasic(AbstractHttpConfigurer::disable)
                .formLogin(AbstractHttpConfigurer::disable) // Deshabilitar formulario de login
                .csrf(AbstractHttpConfigurer::disable)
                .addFilter(new org.springframework.web.filter.CorsFilter(corsConfigurationSource())); // Agregar manualmente el filtro C

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();

        // Especificar dominios permitidos
        configuration.setAllowedOriginPatterns(Arrays.asList("http://localhost:4200","https://zurich-front-server-234b3b208b3f.herokuapp.com")); // Cambia según tu frontend
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH")); // Métodos HTTP permitidos
        configuration.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type", "X-Requested-With")); // Encabezados permitidos
        configuration.setExposedHeaders(Arrays.asList("Authorization")); // Encabezados que el cliente puede leer
        configuration.setAllowCredentials(true); // Permitir credenciales (cookies, encabezados de autorización, etc.)
        configuration.setMaxAge(3600L); // Caché de preflight

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration); // Aplicar configuración a todas las rutas
        return source;
    }


}
