package ec.com.zurich_service.repositories;

import ec.com.zurich_service.resource.entities.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.stream.Stream;

public interface ClienteRepository extends JpaRepository<Cliente, Long>, ClienteRepositoryCustom {

    Stream<Cliente> findByUsuarioId(Long usuarioId);
}
