package ec.com.zurich_service.resource.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EstadoPolizaEnum implements EnumWithValue {
    ACTIVA("A"),
    CANCELADA("C");

    private final String value;

    public static EstadoPolizaEnum fromValue(String value) {
        for (EstadoPolizaEnum tipo : EstadoPolizaEnum.values()) {
            if (tipo.getValue().equals(value)) {
                return tipo;
            }
        }
        // Lanzar una excepción o devolver un valor por defecto si no se encuentra
        throw new IllegalArgumentException("No enum constant for value: " + value);
    }
}