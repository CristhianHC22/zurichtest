package ec.com.zurich_service.resource.validation;

public interface PostValidationGroup {
}
