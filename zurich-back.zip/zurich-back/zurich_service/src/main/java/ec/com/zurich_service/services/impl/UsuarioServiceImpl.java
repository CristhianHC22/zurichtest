package ec.com.zurich_service.services.impl;

import ec.com.zurich_service.exceptions.ResourceNotFoundException;
import ec.com.zurich_service.repositories.UsuarioRepository;
import ec.com.zurich_service.resource.dto.UsuarioRequest;
import ec.com.zurich_service.resource.entities.Usuario;
import ec.com.zurich_service.services.UsuarioService;
import lombok.AllArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@AllArgsConstructor
public class UsuarioServiceImpl implements UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public Usuario save(UsuarioRequest request) {
        Usuario usuario = new Usuario(null, request.user(), passwordEncoder.encode(request.password()), request.roles());
        return usuarioRepository.save(usuario);
    }

    @Override
    @Transactional
    public Usuario update(Long id, UsuarioRequest request) {
        existById(id);
        Usuario usuario = new Usuario(id, request.user(), passwordEncoder.encode(request.password()), request.roles());
        return usuarioRepository.save(usuario);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        existById(id);
        usuarioRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Usuario> findBy(Long id) {
        return usuarioRepository.findById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Usuario> findByUsername(String userName) {
        return usuarioRepository.findByUsername(userName);
    }

    private void existById(Long id) {
        if (!usuarioRepository.existsById(id)) {
            throw new ResourceNotFoundException("Usuario con id %s no existe".formatted(id));
        }
    }


}
