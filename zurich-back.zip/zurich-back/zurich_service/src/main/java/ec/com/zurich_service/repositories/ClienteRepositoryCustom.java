package ec.com.zurich_service.repositories;

import ec.com.zurich_service.resource.dto.ClienteResponse;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;

public interface ClienteRepositoryCustom {
    List<ClienteResponse> findBy(String nomre, String email, String identificaion, Pageable pageable);
    Long countBy(String nomre, String email, String identificaion);
}
