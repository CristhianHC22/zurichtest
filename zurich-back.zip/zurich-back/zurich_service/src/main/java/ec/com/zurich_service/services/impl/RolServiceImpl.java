package ec.com.zurich_service.services.impl;

import ec.com.zurich_service.repositories.RolRepository;
import ec.com.zurich_service.resource.entities.Rol;
import ec.com.zurich_service.services.RolService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@AllArgsConstructor
public class RolServiceImpl implements RolService {

    private final RolRepository rolRepository;

    @Override
    @Transactional
    public Rol createRol(String rolName) {
        Optional<Rol> adminRoleOptional = rolRepository.findByNombre(rolName);
        Rol adminRole;
        if (adminRoleOptional.isEmpty()) {
            adminRole = new Rol();
            adminRole.setNombre(rolName);
            return rolRepository.save(adminRole);
        } else {
            return adminRoleOptional.get();
        }
    }
}
