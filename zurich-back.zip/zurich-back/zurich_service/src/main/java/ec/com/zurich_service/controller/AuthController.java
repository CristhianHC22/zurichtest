package ec.com.zurich_service.controller;

import ec.com.zurich_service.config.JwtTokenProvider;
import ec.com.zurich_service.resource.dto.AuthRequest;
import ec.com.zurich_service.resource.dto.UsuarioResponse;
import ec.com.zurich_service.resource.entities.Rol;
import ec.com.zurich_service.resource.entities.Usuario;
import ec.com.zurich_service.services.UsuarioService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jdk.jfr.Description;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.stream.Collectors;

@Description("Auth")
@Tag(name = "Auth")
@Slf4j
@RestController
@RequestMapping("/auth")
@AllArgsConstructor
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider jwtTokenProvider;
    private final UsuarioService usuarioService;

    @PostMapping("/login")
    public ResponseEntity<UsuarioResponse> login(@RequestBody AuthRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.username(), request.password()));

        User user = (User) authentication.getPrincipal();

        Usuario usuario = usuarioService.findByUsername(user.getUsername()).orElse(new Usuario());
        String token = jwtTokenProvider.createToken(
                user.getUsername(),
                user.getAuthorities().stream().map(GrantedAuthority::getAuthority).collect(Collectors.toList()));

        return ResponseEntity.ok(new UsuarioResponse(usuario.getUsername(), usuario.getRoles().stream().map(Rol::getId).toList(), token));
    }
}