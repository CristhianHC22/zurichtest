package ec.com.zurich_service.resource.dto;

import ec.com.zurich_service.resource.entities.Rol;

import java.util.Set;

public record UsuarioRequest(String user, String password, Set<Rol> roles) {
}
