package ec.com.zurich_service.interceptor;

import ec.com.zurich_service.config.JwtTokenProvider;
import ec.com.zurich_service.exceptions.BadRequestException;
import ec.com.zurich_service.services.UsuarioService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
@AllArgsConstructor
public class JwtInterceptor implements HandlerInterceptor {

    private final JwtTokenProvider jwtTokenProvider;
    private final UsuarioService usuarioService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String path = request.getRequestURI();

        // Ignorar rutas públicas como Swagger y login
        if (path.startsWith("/swagger-ui") || path.startsWith("/v3/api-docs") || path.startsWith("/auth/login")) {
            return true;
        }
        // Obtener el token de la cabecera Authorization
        String authHeader = request.getHeader("Authorization");

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7); // Remover "Bearer " del token

            try {
                String username = jwtTokenProvider.getUsername(token);
                usuarioService.findByUsername(username)
                        .ifPresentOrElse(usuario -> {
                                    request.setAttribute("username", usuario.getUsername());
                                    request.setAttribute("userId", usuario.getId());
                                },
                                () -> {
                                    throw new BadRequestException("Usuario no encontrado");
                                });

            } catch (Exception e) {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.getWriter().write("Token inválido.");
                return false;
            }
        } else {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("Token no proporcionado.");
            return false;
        }
        return true;
    }
}
