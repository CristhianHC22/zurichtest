package ec.com.zurich_service.services.impl;

import ec.com.zurich_service.exceptions.ResourceNotFoundException;
import ec.com.zurich_service.repositories.ClienteRepository;
import ec.com.zurich_service.resource.dto.*;
import ec.com.zurich_service.resource.entities.Cliente;
import ec.com.zurich_service.resource.entities.Rol;
import ec.com.zurich_service.resource.entities.Usuario;
import ec.com.zurich_service.services.ClienteService;
import ec.com.zurich_service.services.RolService;
import ec.com.zurich_service.services.UsuarioService;
import ec.com.zurich_service.util.UtilService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

@Slf4j
@Service
@AllArgsConstructor
public class ClienteServiceImpl implements ClienteService {

    private final ClienteRepository clienteRepository;
    private final UsuarioService usuarioService;
    private final RolService rolService;

    @Override
    @Transactional
    public ClienteResponse create(ClienteRequest request) {
        Cliente cliente = toEntity(request);
        Rol rol = rolService.createRol(UtilService.ROL_CUSTOMER);
        Usuario usuario = usuarioService.save(new UsuarioRequest(request.identificacion(), request.identificacion(), Set.of(rol)));
        cliente.setUsuarioId(usuario.getId());
        return toResponse(clienteRepository.save(cliente));
    }

    @Override
    @Transactional
    public ClienteResponse update(Long id, ClienteRequest request) {
        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cliente con id %s no existe".formatted(id)));

        cliente.setEmail(request.email());
        cliente.setTelefono(request.telefono());
        return toResponse(clienteRepository.save(cliente));
    }

    @Override
    @Transactional
    public ClienteResponse updateSelf(Long userId, ClienteRequest request) {
        Cliente cliente = findByUsuarioId(userId);

        cliente.setEmail(request.email());
        cliente.setTelefono(request.telefono());
        return toResponse(clienteRepository.save(cliente));
    }

    @Override
    @Transactional
    public ClienteResponse delete(Long id) {
        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con id %s".formatted(id)));
        clienteRepository.deleteById(cliente.getId());
        usuarioService.delete(cliente.getUsuarioId());
        return toResponse(cliente);
    }

    @Override
    @Transactional(readOnly = true)
    public ClienteResponse findBy(Long id) {
        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con id %s".formatted(id)));
        return toResponse(cliente);
    }

    @Override
    @Transactional(readOnly = true)
    public ListDto<ClienteResponse> findBy(String nombre, String email, String identificaion, Integer page, Integer limit) {
        page = (page == null) ? 0 : page;
        limit = (limit == null) ? 10 : limit;
        Pageable pageable = PageRequest.of(page, limit);

        List<ClienteResponse> clientes = clienteRepository.findBy(nombre, email, identificaion, pageable);

        Long totalItems = clienteRepository.countBy(nombre, email, identificaion);

        return new ListDto<>(clientes,
                new MetaDto(totalItems.intValue(), clientes.size(), limit, (totalItems.intValue() / limit), page));
    }

    @Override
    @Transactional(readOnly = true)
    public Cliente findByUsuarioId(Long usuarioId) {
        return clienteRepository
                .findByUsuarioId(usuarioId)
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con usuarioId: %s".formatted(usuarioId)));
    }

    @Override
    @Transactional(readOnly = true)
    public ClienteResponse findByMyUsuarioId(Long usuarioId) {
        return toResponse(clienteRepository
                .findByUsuarioId(usuarioId)
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con usuarioId: %s".formatted(usuarioId))));
    }

    private Cliente toEntity(ClienteRequest request) {
        return Cliente.builder()
                .nombre(request.nombre())
                .identificacion(request.identificacion())
                .telefono(request.telefono())
                .email(request.email())
                .build();
    }

    private ClienteResponse toResponse(Cliente cliente) {
        return new ClienteResponse(cliente.getId(), cliente.getNombre(), cliente.getEmail(), cliente.getTelefono(), cliente.getIdentificacion());
    }
}
