package ec.com.zurich_service.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.util.Arrays;
import java.util.List;

@Configuration
public class CorsConfig {

    @Bean
    public CorsFilter corsFilter() {
        CorsConfiguration configuration = new CorsConfiguration();

        // Especificar orígenes permitidos explícitamente (no usar "*")
        configuration.setAllowedOriginPatterns(List.of("http://localhost:4200","https://zurich-front-server-234b3b208b3f.herokuapp.com")); // Cambia esto a tu origen

        // Métodos permitidos
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));

        // Encabezados permitidos
        configuration.setAllowedHeaders(List.of("Authorization", "Content-Type", "X-Requested-With")); // Incluye "Authorization"

        // Permitir el envío de credenciales
        configuration.setAllowCredentials(true);

        // Duración del caché de la respuesta preflight
        configuration.setMaxAge(3600L);

        // Registrar la configuración para todas las rutas
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return new CorsFilter(source);
    }
}
