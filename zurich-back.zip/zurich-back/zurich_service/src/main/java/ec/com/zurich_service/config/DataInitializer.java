package ec.com.zurich_service.config;

import ec.com.zurich_service.resource.dto.UsuarioRequest;
import ec.com.zurich_service.resource.entities.Rol;
import ec.com.zurich_service.services.RolService;
import ec.com.zurich_service.services.UsuarioService;
import ec.com.zurich_service.util.UtilService;
import lombok.AllArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Collections;

@Component
@AllArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UsuarioService usuarioService;
    private final RolService rolService;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Crear el roles si no existe
        rolService.createRol(UtilService.ROL_CUSTOMER);
        Rol adminRole = rolService.createRol(UtilService.ROL_ADMIN);

        // Crear un usuario administrador si no existe
        if (usuarioService.findByUsername("admin").isEmpty()) {
            UsuarioRequest request = new UsuarioRequest("admin", "admin123", Collections.singleton(adminRole));
            usuarioService.save(request);

            System.out.println("Usuario administrador creado: admin / admin123");
        } else {
            System.out.println("El usuario administrador ya existe.");
        }
    }


}
