package ec.com.zurich_service.services;

import ec.com.zurich_service.resource.dto.ClienteRequest;
import ec.com.zurich_service.resource.dto.ClienteResponse;
import ec.com.zurich_service.resource.dto.ListDto;
import ec.com.zurich_service.resource.entities.Cliente;

public interface ClienteService {
    ClienteResponse create(ClienteRequest request);
    ClienteResponse update(Long id, ClienteRequest clienteRequest);
    ClienteResponse delete(Long id);
    ClienteResponse findBy(Long id);
    ListDto<ClienteResponse> findBy(String nombre, String email, String identificaion, Integer page, Integer limit);
    Cliente findByUsuarioId(Long usuarioId);
    ClienteResponse findByMyUsuarioId(Long usuarioId);
    ClienteResponse updateSelf(Long userId, ClienteRequest request);
}
