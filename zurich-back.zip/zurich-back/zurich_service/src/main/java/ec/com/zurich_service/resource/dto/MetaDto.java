package ec.com.zurich_service.resource.dto;

public record MetaDto(int totalItems, int itemCount, int itemsPerPage, int totalPages, int currentPage) {}
