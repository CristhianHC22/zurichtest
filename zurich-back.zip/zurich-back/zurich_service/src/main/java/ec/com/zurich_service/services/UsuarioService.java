package ec.com.zurich_service.services;

import ec.com.zurich_service.resource.dto.UsuarioRequest;
import ec.com.zurich_service.resource.entities.Usuario;

import java.util.Optional;

public interface UsuarioService {
    Usuario save(UsuarioRequest request);
    Usuario update(Long id, UsuarioRequest request);
    Optional<Usuario> findBy(Long id);
    Optional<Usuario> findByUsername(String userName);
    void delete(Long id);
}
