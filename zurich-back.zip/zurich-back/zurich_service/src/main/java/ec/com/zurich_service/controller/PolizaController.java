package ec.com.zurich_service.controller;

import ec.com.zurich_service.resource.dto.ListDto;
import ec.com.zurich_service.resource.dto.PolizaRequest;
import ec.com.zurich_service.resource.dto.PolizaResponse;
import ec.com.zurich_service.resource.enums.EstadoPolizaEnum;
import ec.com.zurich_service.resource.enums.TipoPolizaEnum;
import ec.com.zurich_service.resource.validation.PatchValidationGroup;
import ec.com.zurich_service.resource.validation.PostValidationGroup;
import ec.com.zurich_service.services.PolizaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jdk.jfr.Description;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@Description("Gestión de polizas")
@RestController
@Tag(name = "Polizas")
@RequestMapping("/polizas")
@Slf4j
@AllArgsConstructor
public class PolizaController {

    private final PolizaService polizaService;

    @PreAuthorize("hasAnyRole('ADMIN')")
    @Operation(summary = "Registrar poliza", description = "Se registra un nueva poliza")
    @PostMapping
    public ResponseEntity<PolizaResponse> createPoliza(@Validated(PostValidationGroup.class) @RequestBody PolizaRequest request) {
        return ResponseEntity.ok(polizaService.save(request));
    }

    @PreAuthorize("hasAnyRole('ADMIN')")
    @PatchMapping("/{id}")
    public ResponseEntity<PolizaResponse> updatePoliza(@PathVariable Long id, @Validated(PatchValidationGroup.class) @RequestBody PolizaRequest request) {
        return ResponseEntity.ok(polizaService.update(id, request));
    }

    @PreAuthorize("hasAnyRole('CUSTOMER')")
    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE}, value = "/usuario")
    public ResponseEntity<ListDto<PolizaResponse>> findBy(HttpServletRequest request,
                                                          @RequestParam(required = false, defaultValue = "0", name = "pagina") Integer pagina,
                                                          @RequestParam(required = false, defaultValue = "10", name = "limite") Integer limite) {
        Long userId = (Long) request.getAttribute("userId");
        return ResponseEntity.ok(polizaService.findBy(userId, pagina, limite));
    }

    @PreAuthorize("hasAnyRole('ADMIN')")
    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE}, value = "")
    public ResponseEntity<ListDto<PolizaResponse>> findBy(@RequestParam(name = "tipo", required = false) TipoPolizaEnum tipo,
                                                          @RequestParam(name = "estado", required = false) EstadoPolizaEnum estado,
                                                          @RequestParam(name = "fechaInicio", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fechaInicio,
                                                          @RequestParam(name = "fechaFin", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fechaFin,
                                                          @RequestParam(required = false, defaultValue = "0", name = "pagina") Integer pagina,
                                                          @RequestParam(required = false, defaultValue = "10", name = "limite") Integer limite) {

        return ResponseEntity.ok(polizaService.findBy(tipo, estado, fechaInicio, fechaFin, pagina, limite));
    }

}
