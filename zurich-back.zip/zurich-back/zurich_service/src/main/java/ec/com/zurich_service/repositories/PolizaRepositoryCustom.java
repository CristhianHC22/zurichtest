package ec.com.zurich_service.repositories;

import ec.com.zurich_service.resource.dto.PolizaResponse;
import ec.com.zurich_service.resource.enums.EstadoPolizaEnum;
import ec.com.zurich_service.resource.enums.TipoPolizaEnum;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;

public interface PolizaRepositoryCustom {
    List<PolizaResponse> findBy(TipoPolizaEnum tipo, EstadoPolizaEnum estado, LocalDateTime fechaInicio, LocalDateTime fechaFin, Pageable pageable);
    Long countBy(TipoPolizaEnum tipo, EstadoPolizaEnum estado, LocalDateTime fechaInicio, LocalDateTime fechaFin);
}
