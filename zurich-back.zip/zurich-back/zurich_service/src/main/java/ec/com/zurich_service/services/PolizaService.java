package ec.com.zurich_service.services;

import ec.com.zurich_service.resource.dto.ListDto;
import ec.com.zurich_service.resource.dto.PolizaRequest;
import ec.com.zurich_service.resource.dto.PolizaResponse;
import ec.com.zurich_service.resource.enums.EstadoPolizaEnum;
import ec.com.zurich_service.resource.enums.TipoPolizaEnum;

import java.time.LocalDateTime;

public interface PolizaService {
    PolizaResponse save(PolizaRequest request);
    ListDto<PolizaResponse> findBy(Long usuarioId, Integer page, Integer limit);
    PolizaResponse update(Long id, PolizaRequest request);
    ListDto<PolizaResponse> findBy(TipoPolizaEnum tipo, EstadoPolizaEnum estado, LocalDateTime fechaInicio, LocalDateTime fechaFin, Integer page, Integer limit);
}
