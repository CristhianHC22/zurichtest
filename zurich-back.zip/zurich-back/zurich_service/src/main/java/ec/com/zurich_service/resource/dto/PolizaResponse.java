package ec.com.zurich_service.resource.dto;

import ec.com.zurich_service.resource.enums.EstadoPolizaEnum;
import ec.com.zurich_service.resource.enums.TipoPolizaEnum;
import lombok.Builder;

import java.math.BigDecimal;

@Builder
public record PolizaResponse(
        Long id,
        TipoPolizaEnum tipo,
        BigDecimal montoAsegurado,
        EstadoPolizaEnum estado
) {
    public PolizaResponse(Long id, String tipo, BigDecimal montoAsegurado, String estado) {
        // Convertimos el monto asegurado a BigDecimal
        this(id, TipoPolizaEnum.fromValue(tipo), montoAsegurado, EstadoPolizaEnum.fromValue(estado));
    }
}
