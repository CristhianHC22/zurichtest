package ec.com.zurich_service.resource.dto;

import java.util.List;

public record ListDto<T>(List<T> list, MetaDto meta) {}
