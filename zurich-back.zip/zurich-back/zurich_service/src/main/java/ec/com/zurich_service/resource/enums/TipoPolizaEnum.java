package ec.com.zurich_service.resource.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum TipoPolizaEnum implements EnumWithValue{
    VIDA("V"),
    AUTOMOVIL("A"),
    SALUD("S"),
    HOGAR("H");

    private final String value;

    public static TipoPolizaEnum fromValue(String value) {
        for (TipoPolizaEnum tipo : TipoPolizaEnum.values()) {
            if (tipo.getValue().equals(value)) {
                return tipo;
            }
        }
        // Lanzar una excepción o devolver un valor por defecto si no se encuentra
        throw new IllegalArgumentException("No enum constant for value: " + value);
    }
}