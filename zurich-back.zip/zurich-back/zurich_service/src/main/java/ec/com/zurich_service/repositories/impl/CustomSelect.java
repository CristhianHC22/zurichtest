package ec.com.zurich_service.repositories.impl;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public abstract class CustomSelect {

    @PersistenceContext
    @Autowired
    private EntityManager entityManager;


    @Transactional(readOnly = true)
    public <T> List<T> getList(String select, String where, Map<String, Object> parameters, Class<T> classT, Pageable pageable) {
        String query = "%s %s".formatted(getSelect(select, classT), where);
        return getQueryResult(parameters, query, classT, pageable);
    }

    @Transactional(readOnly = true)
    public <T> T getSingle(String select, String where, Map<String, Object> parameters, Class<T> classT) {
        String query = "%s %s".formatted(getSelect(select, classT), where);
        return getSingleResult(parameters, query, classT);
    }

    private <T> String getSelect(String select, Class<T> classT) {
        return select.formatted(classT.getName());
    }

    private <T> List<T> getQueryResult(Map<String, Object> parameters, String query, Class<T> resultClass, Pageable pageable) {
        if (pageable != null && pageable.getSort().isSorted()) {
            query = query + " ORDER BY ";
            List<String> orderClauses = new ArrayList<>();
            for (Sort.Order order : pageable.getSort()) {
                String orderClause = String.format("m.%s %s", order.getProperty(), order.getDirection());
                orderClauses.add(orderClause);
            }
            query = query + String.join(", ", orderClauses);
        }


        TypedQuery<T> resultQuery = entityManager.createQuery(query, resultClass);
        parameters.forEach(resultQuery::setParameter);


        return (pageable == null)
                ? resultQuery.getResultList()
                : resultQuery.setFirstResult(pageable.getPageNumber() * pageable.getPageSize())
                .setMaxResults(pageable.getPageSize())
                .getResultList();
    }

    private <T> T getSingleResult(Map<String, Object> parameters, String query, Class<T> resultClass) {
        TypedQuery<T> resultQuery = entityManager.createQuery(query, resultClass);
        parameters.forEach(resultQuery::setParameter);
        return resultQuery.getSingleResult();
    }
}
