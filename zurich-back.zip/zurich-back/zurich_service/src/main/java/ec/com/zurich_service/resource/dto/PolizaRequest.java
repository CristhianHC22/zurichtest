package ec.com.zurich_service.resource.dto;

import ec.com.zurich_service.resource.enums.EstadoPolizaEnum;
import ec.com.zurich_service.resource.enums.TipoPolizaEnum;
import ec.com.zurich_service.resource.validation.PatchValidationGroup;
import ec.com.zurich_service.resource.validation.PostValidationGroup;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record PolizaRequest(
        @NotNull(groups = PostValidationGroup.class, message = "El campo tipo no puede ser nulo")
        @Schema(description = "Tipo de poliza, puede ser de VIDA,AUTOMOVIL,SALUD O HOGAR.", example = "AUTOMOVIL")
        TipoPolizaEnum tipo,
        @NotNull(groups = PostValidationGroup.class, message = "El campo fechaInicio no puede ser nulo")
        @Schema(description = "Inicio de vigencia de la poliza", example = "2025-01-16T14:30:00")
        LocalDateTime fechaInicio,
        @NotNull(groups = PostValidationGroup.class, message = "El campo fechaFin no puede ser nulo")
        @Schema(description = "Fin de vigencia de la poliza.", example = "2026-01-16T14:30:00")
        LocalDateTime fechaFin,
        @NotNull(groups = PostValidationGroup.class, message = "El campo montoAsegurado no puede ser nulo")
        @Positive(groups = PostValidationGroup.class, message = "No puede abrir una poliza con saldo negativo o cero")
        @Schema(description = "Monto asegurado de la póliza.", example = "100.00")
        BigDecimal montoAsegurado,
        @NotNull(groups = {PostValidationGroup.class, PatchValidationGroup.class}, message = "El campo estado no puede ser nulo")
        @Schema(description = "Estado de poliza, puede ser de ACTIVA O CANCELADA.", example = "AUTOMOVIL")
        EstadoPolizaEnum estado,
        @NotNull(groups = PostValidationGroup.class, message = "El campo clienteId no puede ser nulo")
        @Schema(description = "Id del cliente asociado a la poliza", example = "1")
        Long clienteId
) {
}