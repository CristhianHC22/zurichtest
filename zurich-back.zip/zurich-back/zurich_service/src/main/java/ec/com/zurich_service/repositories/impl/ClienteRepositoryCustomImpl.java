package ec.com.zurich_service.repositories.impl;

import ec.com.zurich_service.repositories.ClienteRepositoryCustom;
import ec.com.zurich_service.resource.dto.ClienteResponse;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@AllArgsConstructor()
public class ClienteRepositoryCustomImpl extends CustomSelect implements ClienteRepositoryCustom {

    @PersistenceContext
    private final EntityManager entityManager;

    @Override
    @Transactional(readOnly = true)
    public List<ClienteResponse> findBy(String nomre, String email, String identificaion, Pageable pageable) {
        String select = "SELECT NEW %s(c.id,c.nombre,c.email,c.telefono,c.identificacion) FROM Cliente c ";
        StringBuilder whereBuilder = new StringBuilder().append("WHERE c.id IS NOT null ");
        Map<String, Object> parameters = builderClausureWhere(whereBuilder, nomre, email, identificaion);

        return getList(select, whereBuilder.toString(), parameters, ClienteResponse.class, pageable);
    }


    @Override
    @Transactional(readOnly = true)
    public Long countBy(String nomre, String email, String identificacion) {
        String select = "SELECT count(c.id) FROM Cliente c ";
        StringBuilder whereBuilder = new StringBuilder().append("WHERE c.id IS NOT null ");
        Map<String, Object> parameters = builderClausureWhere(whereBuilder, nomre, email, identificacion);

        return getSingle(select, whereBuilder.toString(), parameters, Long.class);
    }

    private Map<String, Object> builderClausureWhere(StringBuilder queryBuilder, String nombre, String email, String identificacion) {
        Map<String, Object> parameters = new HashMap<>();

        boolean existeNombre = StringUtils.isNotEmpty(nombre);
        boolean existeEmail = StringUtils.isNotEmpty(email);
        boolean existeIdentificaion = StringUtils.isNotEmpty(identificacion);
        if (existeNombre) {
            queryBuilder.append(" AND UPPER(c.nombre) like :nombre");
            parameters.put("nombre", nombre.toUpperCase());
        }
        if (existeEmail) {
            queryBuilder.append(" AND c.email = :email");
            parameters.put("email", email);
        }
        if (existeIdentificaion) {
            queryBuilder.append(" AND c.identificacion = :identificacion");
            parameters.put("identificacion", identificacion);
        }
        return parameters;
    }
}
