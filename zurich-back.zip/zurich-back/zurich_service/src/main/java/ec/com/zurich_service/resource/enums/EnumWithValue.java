package ec.com.zurich_service.resource.enums;

public interface EnumWithValue {
    String getValue();
}
