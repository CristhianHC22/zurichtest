package ec.com.zurich_service.services;

import ec.com.zurich_service.exceptions.BadRequestException;
import ec.com.zurich_service.repositories.UsuarioRepository;
import ec.com.zurich_service.resource.entities.Usuario;
import lombok.AllArgsConstructor;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final UsuarioRepository usuarioRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Usuario usuario = usuarioRepository.findByUsername(username)
                .orElseThrow(() -> new BadRequestException("Usuario no encontrado"));

        var authorities = usuario.getRoles().stream()
                .map(rol -> "ROLE_" + rol.getNombre()) // Prefijo ROLE_ requerido por Spring Security
                .toList();

        return User.builder()
                .username(usuario.getUsername())
                .password(usuario.getPassword()) // Asegúrate de usar contraseñas encriptadas // Contraseña cifrada
                .authorities(authorities.toArray(new String[0]))
                .build();
    }
}
