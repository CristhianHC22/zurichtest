package ec.com.zurich_service.resource.dto;

public record AuthRequest(
        String username,
        String password) {
}
