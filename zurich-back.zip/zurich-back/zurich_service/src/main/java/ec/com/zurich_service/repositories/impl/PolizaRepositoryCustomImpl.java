package ec.com.zurich_service.repositories.impl;

import ec.com.zurich_service.repositories.PolizaRepositoryCustom;
import ec.com.zurich_service.resource.dto.PolizaResponse;
import ec.com.zurich_service.resource.enums.EstadoPolizaEnum;
import ec.com.zurich_service.resource.enums.TipoPolizaEnum;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@AllArgsConstructor()
public class PolizaRepositoryCustomImpl extends CustomSelect implements PolizaRepositoryCustom {

    @PersistenceContext
    private final EntityManager entityManager;

    @Override
    @Transactional(readOnly = true)
    public List<PolizaResponse> findBy(TipoPolizaEnum tipo, EstadoPolizaEnum estado, LocalDateTime fechaInicio, LocalDateTime fechaFin, Pageable pageable) {
        String select = "SELECT NEW %s(p.id,p.tipoPoliza,p.montoAsegurado,p.estado) FROM Poliza p ";
        StringBuilder whereBuilder = new StringBuilder().append("WHERE p.id IS NOT null ");
        Map<String, Object> parameters = builderClausureWhere(whereBuilder, tipo, estado, fechaInicio, fechaFin);

        return getList(select, whereBuilder.toString(), parameters, PolizaResponse.class, pageable);
    }

    @Override
    @Transactional(readOnly = true)
    public Long countBy(TipoPolizaEnum tipo, EstadoPolizaEnum estado, LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        String select = "SELECT count(p.id) FROM Poliza p ";
        StringBuilder whereBuilder = new StringBuilder().append("WHERE p.id IS NOT null ");
        Map<String, Object> parameters = builderClausureWhere(whereBuilder, tipo, estado, fechaInicio, fechaFin);

        return getSingle(select, whereBuilder.toString(), parameters, Long.class);
    }

    private Map<String, Object> builderClausureWhere(StringBuilder queryBuilder, TipoPolizaEnum tipo, EstadoPolizaEnum estado, LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        Map<String, Object> parameters = new HashMap<>();

        boolean existeTipo = tipo != null;
        boolean existeEstado = estado != null;
        boolean existeFechaInicio = fechaInicio != null;
        boolean existeFechaFin = fechaFin != null;
        if (existeTipo) {
            queryBuilder.append(" AND p.tipoPoliza = :tipoPoliza");
            parameters.put("tipoPoliza", tipo.getValue());
        }
        if (existeEstado) {
            queryBuilder.append(" AND p.estado = :estado");
            parameters.put("estado", estado.getValue());
        }
        if (existeFechaInicio) {
            queryBuilder.append(" AND p.fechaInicio >= :fechaInicio");
            parameters.put("fechaInicio", fechaInicio);
        }
        if (existeFechaFin) {
            queryBuilder.append(" AND p.fechaFin <= :fechaFin");
            parameters.put("fechaFin", fechaFin);
        }
        return parameters;
    }
}
