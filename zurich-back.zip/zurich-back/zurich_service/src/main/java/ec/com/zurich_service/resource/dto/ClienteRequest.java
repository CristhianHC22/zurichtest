package ec.com.zurich_service.resource.dto;

import ec.com.zurich_service.resource.validation.PatchValidationGroup;
import ec.com.zurich_service.resource.validation.PostValidationGroup;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;

public record ClienteRequest(
        @NotNull(groups = PostValidationGroup.class, message = "El campo nombre no puede ser nulo")
        @NotEmpty(groups = PostValidationGroup.class, message = "El campo nombre no puede ser vacio")
        @NotBlank(groups = PostValidationGroup.class, message = "El campo nombre no puede estar en blanco")
        @Pattern(groups = PostValidationGroup.class, regexp = "^[A-Za-záéíóúÁÉÍÓÚÑñ ]+$", message = "El campo nombre solo puede contener letras y espacios")
        @Schema(description = "Nombre del cliente, favor ingresar minimo un nombre y un apellido", example = "Cristhian Holguin")
        String nombre,
        @NotNull(groups = PostValidationGroup.class, message = "El campo identificación no puede ser nulo")
        @NotEmpty(groups = PostValidationGroup.class, message = "El campo identificación no puede ser vacio")
        @NotBlank(groups = PostValidationGroup.class, message = "El campo identificación no puede estar en blanco")
        @Schema(description = "Identificación del cliente", example = "1234567890")
        @Size(groups = PostValidationGroup.class, min = 10, max = 10, message = "El campo identificación debe tener exactamente 10 dígitos")
        @Pattern(groups = PostValidationGroup.class, regexp = "^[0-9]{10}$", message = "El campo identificación debe contener solo dígitos")
        String identificacion,
        @NotNull(groups = {PostValidationGroup.class, PatchValidationGroup.class}, message = "El campo telefono no puede ser nulo")
        @NotEmpty(groups = {PostValidationGroup.class, PatchValidationGroup.class}, message = "El campo telefono no puede ser vacio")
        @NotBlank(message = "El campo telefono no puede estar en blanco")
        @Schema(description = "Telefono del cliente", example = "0963861873")
        String telefono,
        @NotNull(groups = {PostValidationGroup.class, PatchValidationGroup.class}, message = "El campo contrasena no puede ser nulo")
        @NotEmpty(groups = {PostValidationGroup.class, PatchValidationGroup.class}, message = "El campo contrasena no puede ser vacio")
        @NotBlank(groups = {PostValidationGroup.class, PatchValidationGroup.class}, message = "El campo contrasena no puede estar en blanco")
        @Schema(description = "Contraseña del cliente", example = "13456")
        @Email(groups = {PostValidationGroup.class, PatchValidationGroup.class}, message = "Debe ser un email válido")
        String email
) {
}