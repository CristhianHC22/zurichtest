package ec.com.zurich_service.services.impl;

import ec.com.zurich_service.exceptions.InvalidOperationException;
import ec.com.zurich_service.exceptions.ResourceNotFoundException;
import ec.com.zurich_service.repositories.PolizaRepository;
import ec.com.zurich_service.resource.dto.*;
import ec.com.zurich_service.resource.entities.Cliente;
import ec.com.zurich_service.resource.entities.Poliza;
import ec.com.zurich_service.resource.enums.EstadoPolizaEnum;
import ec.com.zurich_service.resource.enums.TipoPolizaEnum;
import ec.com.zurich_service.services.ClienteService;
import ec.com.zurich_service.services.PolizaService;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@AllArgsConstructor
public class PolizaServiceImpl implements PolizaService {

    private final PolizaRepository polizaRepository;
    private final ClienteService clienteService;

    @Override
    @Transactional
    public PolizaResponse save(PolizaRequest request) {
        if (request.fechaInicio().isAfter(request.fechaFin())) {
            throw new InvalidOperationException("La fecha fin debe ser posterior a la fecha inicio");
        }

        Poliza poliza = toEntity(request);
        ClienteResponse cliente = clienteService.findBy(request.clienteId());
        poliza.setClienteId(cliente.id());
        poliza = polizaRepository.save(poliza);
        return toResponse(poliza);
    }

    @Override
    @Transactional
    public PolizaResponse update(Long id, PolizaRequest request) {
        Poliza poliza = polizaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Poliza no encontrada con id: %s".formatted(id)));
        poliza.setEstado(request.estado().getValue());
        poliza = polizaRepository.save(poliza);
        return toResponse(poliza);
    }

    @Override
    @Transactional(readOnly = true)
    public ListDto<PolizaResponse> findBy(Long usuarioId, Integer page, Integer limit) {
        Cliente cliente = clienteService.findByUsuarioId(usuarioId);
        page = (page == null) ? 0 : page;
        limit = (limit == null) ? 10 : limit;
        Pageable pageable = PageRequest.of(page, limit);

        Page<Poliza> clientesPage = polizaRepository.findByClienteId(cliente.getId(), pageable);

        int totalItems = polizaRepository.countByClienteId(cliente.getId());
        List<PolizaResponse> clientes = clientesPage.getContent()
                .stream()
                .map(this::toResponse)
                .toList();

        return new ListDto<>(clientes,
                new MetaDto(totalItems, clientes.size(), limit, (totalItems / limit), page));
    }

    @Override
    @Transactional(readOnly = true)
    public ListDto<PolizaResponse> findBy(TipoPolizaEnum tipo, EstadoPolizaEnum estado, LocalDateTime fechaInicio, LocalDateTime fechaFin, Integer page, Integer limit) {
        page = (page == null) ? 0 : page;
        limit = (limit == null) ? 10 : limit;
        Pageable pageable = PageRequest.of(page, limit);

        List<PolizaResponse> polizas = polizaRepository.findBy(tipo, estado, fechaInicio, fechaFin, pageable);

        Long totalItems = polizaRepository.countBy(tipo, estado, fechaInicio, fechaFin);

        return new ListDto<>(polizas,
                new MetaDto(totalItems.intValue(), polizas.size(), limit, (totalItems.intValue() / limit), page));
    }

    private Poliza toEntity(PolizaRequest request) {
        return Poliza.builder()
                .tipoPoliza(request.tipo().getValue())
                .fechaInicio(request.fechaInicio())
                .fechaFin(request.fechaFin())
                .montoAsegurado(request.montoAsegurado())
                .estado(request.estado().getValue())
                .build();
    }

    private PolizaResponse toResponse(Poliza poliza) {
        return PolizaResponse.builder()
                .id(poliza.getId())
                .tipo(TipoPolizaEnum.fromValue(poliza.getTipoPoliza()))
                .montoAsegurado(poliza.getMontoAsegurado())
                .estado(EstadoPolizaEnum.fromValue(poliza.getEstado()))
                .build();
    }
}