package ec.com.zurich_service.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class UtilService {
    public String ROL_ADMIN= "ADMIN";
    public String ROL_CUSTOMER= "CUSTOMER";
}
