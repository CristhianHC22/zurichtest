package ec.com.zurich_service.repositories;

import ec.com.zurich_service.resource.entities.Poliza;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PolizaRepository extends JpaRepository<Poliza, Long>,PolizaRepositoryCustom {
    Page<Poliza> findByClienteId(Long clienteId, Pageable pageable);
    int countByClienteId(Long clienteId);
}
