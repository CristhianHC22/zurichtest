package ec.com.zurich_service.resource.dto;

import java.util.List;

public record UsuarioResponse(
        String usuario,
        List<Long> rolId,
        String token
) {
}
