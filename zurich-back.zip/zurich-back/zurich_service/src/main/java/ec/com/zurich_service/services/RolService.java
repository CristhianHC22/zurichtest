package ec.com.zurich_service.services;

import ec.com.zurich_service.resource.entities.Rol;

public interface RolService {
    Rol createRol(String rolName);
}
