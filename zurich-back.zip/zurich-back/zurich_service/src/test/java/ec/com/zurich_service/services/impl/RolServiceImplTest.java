package ec.com.zurich_service.services.impl;

import ec.com.zurich_service.repositories.RolRepository;
import ec.com.zurich_service.resource.entities.Rol;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RolServiceImplTest {

    @Mock
    private RolRepository rolRepository;

    @InjectMocks
    private RolServiceImpl rolService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createRol_ShouldCreateAndSaveNewRolIfNotExists() {
        // Arrange
        String rolName = "ROLE_ADMIN";
        Rol newRol = new Rol();
        newRol.setNombre(rolName);

        when(rolRepository.findByNombre(rolName)).thenReturn(Optional.empty());
        when(rolRepository.save(any(Rol.class))).thenReturn(newRol);

        // Act
        Rol result = rolService.createRol(rolName);

        // Assert
        assertNotNull(result);
        assertEquals(rolName, result.getNombre());

        verify(rolRepository, times(1)).findByNombre(rolName);
        verify(rolRepository, times(1)).save(any(Rol.class));
    }

    @Test
    void createRol_ShouldReturnExistingRolIfAlreadyExists() {
        // Arrange
        String rolName = "ROLE_USER";
        Rol existingRol = new Rol();
        existingRol.setNombre(rolName);

        when(rolRepository.findByNombre(rolName)).thenReturn(Optional.of(existingRol));

        // Act
        Rol result = rolService.createRol(rolName);

        // Assert
        assertNotNull(result);
        assertEquals(rolName, result.getNombre());

        verify(rolRepository, times(1)).findByNombre(rolName);
        verify(rolRepository, times(0)).save(any(Rol.class)); // No debe guardar un nuevo rol.
    }
}
