package ec.com.zurich_service.services.impl;

import ec.com.zurich_service.exceptions.InvalidOperationException;
import ec.com.zurich_service.exceptions.ResourceNotFoundException;
import ec.com.zurich_service.repositories.PolizaRepository;
import ec.com.zurich_service.resource.dto.ClienteResponse;
import ec.com.zurich_service.resource.dto.ListDto;
import ec.com.zurich_service.resource.dto.PolizaRequest;
import ec.com.zurich_service.resource.dto.PolizaResponse;
import ec.com.zurich_service.resource.entities.Cliente;
import ec.com.zurich_service.resource.entities.Poliza;
import ec.com.zurich_service.resource.enums.EstadoPolizaEnum;
import ec.com.zurich_service.resource.enums.TipoPolizaEnum;
import ec.com.zurich_service.services.ClienteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PolizaServiceImplTest {

    @Mock
    private PolizaRepository polizaRepository;

    @Mock
    private ClienteService clienteService;

    @InjectMocks
    private PolizaServiceImpl polizaService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void save_ShouldThrowExceptionIfFechaInicioIsAfterFechaFin() {
        // Arrange
        PolizaRequest request = new PolizaRequest(TipoPolizaEnum.HOGAR, LocalDateTime.now().plusDays(1), LocalDateTime.now(), BigDecimal.valueOf(10000), EstadoPolizaEnum.ACTIVA, 1L);

        // Act & Assert
        InvalidOperationException exception = assertThrows(InvalidOperationException.class, () -> polizaService.save(request));
        assertEquals("La fecha fin debe ser posterior a la fecha inicio", exception.getMessage());
    }

    @Test
    void save_ShouldSavePolizaWhenValid() {
        // Arrange
        PolizaRequest request = new PolizaRequest(TipoPolizaEnum.HOGAR, LocalDateTime.now(), LocalDateTime.now().plusDays(1), BigDecimal.valueOf(10000), EstadoPolizaEnum.ACTIVA, 1L);
        ClienteResponse clienteResponse = new ClienteResponse(1L, "John Doe", "demo@demo.com", "", "");
        Poliza poliza = Poliza.builder().tipoPoliza(TipoPolizaEnum.HOGAR.getValue()).fechaInicio(request.fechaInicio()).fechaFin(request.fechaFin()).montoAsegurado(request.montoAsegurado()).estado(request.estado().getValue()).build();
        PolizaResponse expectedResponse = new PolizaResponse(1L, TipoPolizaEnum.HOGAR, request.montoAsegurado(), EstadoPolizaEnum.ACTIVA);

        when(clienteService.findBy(request.clienteId())).thenReturn(clienteResponse);
        when(polizaRepository.save(any(Poliza.class))).thenReturn(poliza);

        // Act
        PolizaResponse result = polizaService.save(request);

        // Assert
        assertNotNull(result);
        assertEquals(expectedResponse.tipo(), result.tipo());
        assertEquals(expectedResponse.montoAsegurado(), result.montoAsegurado());
        verify(polizaRepository, times(1)).save(any(Poliza.class));
    }

    @Test
    void update_ShouldThrowExceptionIfPolizaNotFound() {
        // Arrange
        Long id = 1L;
        PolizaRequest request = new PolizaRequest(TipoPolizaEnum.HOGAR, LocalDateTime.now(), LocalDateTime.now().plusDays(1), BigDecimal.valueOf(10000), EstadoPolizaEnum.ACTIVA, 1L);

        when(polizaRepository.findById(id)).thenReturn(Optional.empty());

        // Act & Assert
        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> polizaService.update(id, request));
        assertEquals("Poliza no encontrada con id: 1", exception.getMessage());
    }

    @Test
    void update_ShouldUpdatePolizaWhenExists() {
        // Arrange
        Long id = 1L;
        PolizaRequest request = new PolizaRequest(TipoPolizaEnum.HOGAR, LocalDateTime.now(), LocalDateTime.now().plusDays(1), BigDecimal.valueOf(10000), EstadoPolizaEnum.ACTIVA, 1L);
        Poliza existingPoliza = Poliza.builder().id(id).tipoPoliza(TipoPolizaEnum.HOGAR.getValue()).fechaInicio(request.fechaInicio()).fechaFin(request.fechaFin()).montoAsegurado(request.montoAsegurado()).estado(EstadoPolizaEnum.ACTIVA.getValue()).build();
        PolizaResponse expectedResponse = new PolizaResponse(id, TipoPolizaEnum.HOGAR, request.montoAsegurado(), EstadoPolizaEnum.ACTIVA);

        when(polizaRepository.findById(id)).thenReturn(Optional.of(existingPoliza));
        when(polizaRepository.save(any(Poliza.class))).thenReturn(existingPoliza);

        // Act
        PolizaResponse result = polizaService.update(id, request);

        // Assert
        assertNotNull(result);
        assertEquals(expectedResponse.estado().getValue(), result.estado().getValue());
        verify(polizaRepository, times(1)).findById(id);
        verify(polizaRepository, times(1)).save(any(Poliza.class));
    }

    @Test
    void findBy_ShouldReturnListOfPolizas() {
        // Arrange
        Long usuarioId = 1L;
        Integer page = 0;
        Integer limit = 10;
        Cliente cliente = new Cliente();
        cliente.setId(1L);
        Poliza poliza = new Poliza();
        poliza.setId(1L);
        poliza.setTipoPoliza(TipoPolizaEnum.HOGAR.getValue());
        poliza.setEstado(EstadoPolizaEnum.ACTIVA.getValue());

        PolizaResponse polizaResponse = new PolizaResponse(1L, TipoPolizaEnum.HOGAR, BigDecimal.valueOf(10000), EstadoPolizaEnum.ACTIVA);
        Page<Poliza> polizasPage = mock(Page.class);
        when(polizaRepository.findByClienteId(cliente.getId(), PageRequest.of(page, limit))).thenReturn(polizasPage);
        when(polizasPage.getContent()).thenReturn(List.of(poliza));
        when(polizaRepository.countByClienteId(cliente.getId())).thenReturn(1);
        when(clienteService.findByUsuarioId(usuarioId)).thenReturn(cliente);

        // Act
        ListDto<PolizaResponse> result = polizaService.findBy(usuarioId, page, limit);

        // Assert
        assertNotNull(result);
        assertFalse(result.list().isEmpty());
        assertEquals(1, result.list().size());
        verify(polizaRepository, times(1)).findByClienteId(cliente.getId(), PageRequest.of(page, limit));
    }
}
