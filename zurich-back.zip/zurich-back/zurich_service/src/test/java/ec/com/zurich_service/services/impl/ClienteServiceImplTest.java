package ec.com.zurich_service.services.impl;

import ec.com.zurich_service.exceptions.ResourceNotFoundException;
import ec.com.zurich_service.repositories.ClienteRepository;
import ec.com.zurich_service.resource.dto.ClienteRequest;
import ec.com.zurich_service.resource.dto.ClienteResponse;
import ec.com.zurich_service.resource.dto.ListDto;
import ec.com.zurich_service.resource.dto.UsuarioRequest;
import ec.com.zurich_service.resource.entities.Cliente;
import ec.com.zurich_service.resource.entities.Rol;
import ec.com.zurich_service.resource.entities.Usuario;
import ec.com.zurich_service.services.RolService;
import ec.com.zurich_service.services.UsuarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ClienteServiceImplTest {

    @Mock
    private ClienteRepository clienteRepository;

    @Mock
    private UsuarioService usuarioService;

    @Mock
    private RolService rolService;

    @InjectMocks
    private ClienteServiceImpl clienteService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void create_ShouldCreateClienteWithUsuarioAndRol() {
        // Arrange
        ClienteRequest request = new ClienteRequest("John Doe", "1234567890", "johndoe@example.com", "1234567890");
        Rol rol = new Rol();
        rol.setNombre("CUSTOMER");
        Usuario usuario = new Usuario(1L, "1234567890", "1234567890", Set.of(rol));
        Cliente cliente = new Cliente(1L, "John Doe", "1234567890", "johndoe@example.com", "1234567890", 1L, new Usuario());

        when(rolService.createRol("CUSTOMER")).thenReturn(rol);
        when(usuarioService.save(any(UsuarioRequest.class))).thenReturn(usuario);
        when(clienteRepository.save(any(Cliente.class))).thenReturn(cliente);

        // Act
        ClienteResponse result = clienteService.create(request);

        // Assert
        assertNotNull(result);
        assertEquals(cliente.getId(), result.id());
        assertEquals(cliente.getNombre(), result.nombre());
        verify(rolService, times(1)).createRol("CUSTOMER");
        verify(usuarioService, times(1)).save(any(UsuarioRequest.class));
        verify(clienteRepository, times(1)).save(any(Cliente.class));
    }

    @Test
    void update_ShouldThrowExceptionIfClienteNotFound() {
        // Arrange
        Long id = 1L;
        ClienteRequest request = new ClienteRequest("John Doe", "1234567890", "johndoe@example.com", "1234567890");

        when(clienteRepository.findById(id)).thenReturn(Optional.empty());

        // Act & Assert
        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> clienteService.update(id, request));
        assertEquals("Cliente con id 1 no existe", exception.getMessage());
    }

    @Test
    void update_ShouldUpdateClienteIfFound() {
        // Arrange
        Long id = 1L;
        ClienteRequest request = new ClienteRequest("John Doe", "1234567890", "johndoe@example.com", "1234567890");
        Cliente cliente = new Cliente(id, "John Doe", "1234567890", "johndoe@example.com", "1234567890", 1L, new Usuario());

        when(clienteRepository.findById(id)).thenReturn(Optional.of(cliente));
        when(clienteRepository.save(any(Cliente.class))).thenReturn(cliente);

        // Act
        ClienteResponse result = clienteService.update(id, request);

        // Assert
        assertNotNull(result);
        assertEquals(cliente.getEmail(), result.email());
        assertEquals(cliente.getTelefono(), result.telefono());
        verify(clienteRepository, times(1)).findById(id);
        verify(clienteRepository, times(1)).save(any(Cliente.class));
    }

    @Test
    void delete_ShouldThrowExceptionIfClienteNotFound() {
        // Arrange
        Long id = 1L;

        when(clienteRepository.findById(id)).thenReturn(Optional.empty());

        // Act & Assert
        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> clienteService.delete(id));
        assertEquals("Cliente no encontrado con id 1", exception.getMessage());
    }

    @Test
    void delete_ShouldDeleteClienteAndAssociatedUsuario() {
        // Arrange
        Long id = 1L;
        Cliente cliente = new Cliente(id, "John Doe", "1234567890", "johndoe@example.com", "1234567890", 1L, new Usuario());
        Usuario usuario = new Usuario(1L, "1234567890", "1234567890", Set.of(new Rol(1L, "CUSTOMER")));

        when(clienteRepository.findById(id)).thenReturn(Optional.of(cliente));
        //when(clienteRepository.deleteById(id)).thenReturn(null);
        //when(usuarioService.delete(id)).thenReturn(null);

        // Act
        ClienteResponse result = clienteService.delete(id);

        // Assert
        assertNotNull(result);
        verify(clienteRepository, times(1)).findById(id);
        verify(clienteRepository, times(1)).deleteById(id);
        verify(usuarioService, times(1)).delete(id);
    }

    @Test
    void findBy_ShouldThrowExceptionIfClienteNotFound() {
        // Arrange
        Long id = 1L;
        when(clienteRepository.findById(id)).thenReturn(Optional.empty());

        // Act & Assert
        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> clienteService.findBy(id));
        assertEquals("Cliente no encontrado con id 1", exception.getMessage());
    }

    @Test
    void findBy_ShouldReturnClienteIfFound() {
        // Arrange
        Long id = 1L;
        Cliente cliente = new Cliente(id, "John Doe", "1234567890", "johndoe@example.com", "1234567890", 1L, new Usuario());
        ClienteResponse expectedResponse = new ClienteResponse(id, "John Doe", "johndoe@example.com", "1234567890", "1234567890");

        when(clienteRepository.findById(id)).thenReturn(Optional.of(cliente));

        // Act
        ClienteResponse result = clienteService.findBy(id);

        // Assert
        assertNotNull(result);
        assertEquals(expectedResponse.id(), result.id());
        assertEquals(expectedResponse.nombre(), result.nombre());
    }

    @Test
    void findByMyUsuarioId_ShouldReturnClienteIfFound() {
        // Arrange
        Long usuarioId = 1L;
        Cliente cliente = new Cliente(1L, "John Doe", "1234567890", "johndoe@example.com", "1234567890", usuarioId, new Usuario());
        ClienteResponse expectedResponse = new ClienteResponse(1L, "John Doe", "johndoe@example.com", "1234567890", "1234567890");

        when(clienteRepository.findByUsuarioId(usuarioId)).thenReturn(Stream.of(cliente));

        // Act
        ClienteResponse result = clienteService.findByMyUsuarioId(usuarioId);

        // Assert
        assertNotNull(result);
        assertEquals(expectedResponse.id(), result.id());
        assertEquals(expectedResponse.nombre(), result.nombre());
    }

    @Test
    void findBy_ShouldReturnClientesList() {
        // Arrange
        String nombre = "John";
        String email = "johndoe@example.com";
        String identificacion = "1234567890";
        Integer page = 0;
        Integer limit = 10;

        Cliente cliente = new Cliente(1L, "John Doe", "1234567890", "johndoe@example.com", "1234567890", 1L, new Usuario());
        ClienteResponse clienteResponse = new ClienteResponse(1L, "John Doe", "johndoe@example.com", "1234567890", "1234567890");

        Pageable pageable = PageRequest.of(page, limit);
        //when(clienteRepository.findBy(nombre, email, identificacion, pageable)).thenReturn(List.of(cliente));
        when(clienteRepository.countBy(nombre, email, identificacion)).thenReturn(1L);

        // Act
        ListDto<ClienteResponse> result = clienteService.findBy(nombre, email, identificacion, page, limit);

        // Assert
        assertNotNull(result);
    }
}
