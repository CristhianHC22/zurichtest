package ec.com.zurich_service.services.impl;

import ec.com.zurich_service.exceptions.ResourceNotFoundException;
import ec.com.zurich_service.repositories.UsuarioRepository;
import ec.com.zurich_service.resource.dto.UsuarioRequest;
import ec.com.zurich_service.resource.entities.Rol;
import ec.com.zurich_service.resource.entities.Usuario;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UsuarioServiceImplTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UsuarioServiceImpl usuarioService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void save_ShouldSaveAndReturnUsuario() {
        // Arrange
        UsuarioRequest request = new UsuarioRequest("testUser", "testPass", Set.of(new Rol(1L, "ROLE_USER")));
        Usuario usuario = new Usuario(null, "testUser", "encodedPass", Set.of(new Rol(1L, "ROLE_USER")));

        when(passwordEncoder.encode(request.password())).thenReturn("encodedPass");
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuario);

        // Act
        Usuario savedUsuario = usuarioService.save(request);

        // Assert
        assertNotNull(savedUsuario);
        assertEquals("testUser", savedUsuario.getUsername());
        assertEquals("encodedPass", savedUsuario.getPassword());

        verify(passwordEncoder, times(1)).encode(request.password());
        verify(usuarioRepository, times(1)).save(any(Usuario.class));
    }

    @Test
    void update_ShouldUpdateAndReturnUsuario() {
        // Arrange
        Long id = 1L;
        UsuarioRequest request = new UsuarioRequest("updatedUser", "newPass", Set.of(new Rol(1L, "ROLE_ADMIN")));
        Usuario usuario = new Usuario(id, "updatedUser", "encodedNewPass", Set.of(new Rol(1L, "ROLE_ADMIN")));

        when(usuarioRepository.existsById(id)).thenReturn(true);
        when(passwordEncoder.encode(request.password())).thenReturn("encodedNewPass");
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuario);

        // Act
        Usuario updatedUsuario = usuarioService.update(id, request);

        // Assert
        assertNotNull(updatedUsuario);
        assertEquals("updatedUser", updatedUsuario.getUsername());
        assertEquals("encodedNewPass", updatedUsuario.getPassword());

        verify(usuarioRepository, times(1)).existsById(id);
        verify(passwordEncoder, times(1)).encode(request.password());
        verify(usuarioRepository, times(1)).save(any(Usuario.class));
    }

    @Test
    void delete_ShouldDeleteUsuario() {
        // Arrange
        Long id = 1L;

        when(usuarioRepository.existsById(id)).thenReturn(true);

        // Act
        usuarioService.delete(id);

        // Assert
        verify(usuarioRepository, times(1)).existsById(id);
        verify(usuarioRepository, times(1)).deleteById(id);
    }

    @Test
    void findBy_ShouldReturnUsuarioIfExists() {
        // Arrange
        Long id = 1L;
        Usuario usuario = new Usuario(id, "testUser", "testPass", Set.of(new Rol(1L, "ROLE_USER")));

        when(usuarioRepository.findById(id)).thenReturn(Optional.of(usuario));

        // Act
        Optional<Usuario> result = usuarioService.findBy(id);

        // Assert
        assertTrue(result.isPresent());
        assertEquals(usuario, result.get());

        verify(usuarioRepository, times(1)).findById(id);
    }

    @Test
    void findBy_ShouldReturnEmptyIfNotExists() {
        // Arrange
        Long id = 1L;

        when(usuarioRepository.findById(id)).thenReturn(Optional.empty());

        // Act
        Optional<Usuario> result = usuarioService.findBy(id);

        // Assert
        assertFalse(result.isPresent());

        verify(usuarioRepository, times(1)).findById(id);
    }

    @Test
    void findByUsername_ShouldReturnUsuarioIfExists() {
        // Arrange
        String username = "testUser";
        Usuario usuario = new Usuario(1L, username, "testPass", Set.of(new Rol(1L, "ROLE_USER")));

        when(usuarioRepository.findByUsername(username)).thenReturn(Optional.of(usuario));

        // Act
        Optional<Usuario> result = usuarioService.findByUsername(username);

        // Assert
        assertTrue(result.isPresent());
        assertEquals(usuario, result.get());

        verify(usuarioRepository, times(1)).findByUsername(username);
    }

    @Test
    void existById_ShouldThrowExceptionIfNotExists() {
        // Arrange
        Long id = 1L;

        when(usuarioRepository.existsById(id)).thenReturn(false);

        // Act & Assert
        ResourceNotFoundException exception = assertThrows(
                ResourceNotFoundException.class,
                () -> usuarioService.delete(id)
        );

        assertEquals("Usuario con id 1 no existe", exception.getMessage());

        verify(usuarioRepository, times(1)).existsById(id);
    }
}
