import { HttpInterceptorFn } from '@angular/common/http';

/*export const authInterceptor: HttpInterceptorFn = (req, next) => {
  console.log('Interceptor ejecutado');
  console.log('URL de la solicitud:', req.url); // Verifica si la solicitud está pasando por aquí
  
  // Si la URL es la del login, no modificamos la solicitud
  if (req.url === 'http://localhost:8080/auth/login') {
    console.log('Solicitud de login, no se añade el token');
    return next(req);  // No hacemos nada con la solicitud de login
  }

  // Si no es el login, añade el token a las cabeceras
  const token = localStorage.getItem('token');
  if (token) {
    console.log('Token encontrado:', token);
    const clonedRequest = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      },
    });
    return next(clonedRequest);  // Continuamos con la solicitud clonada
  }

  // Si no hay token, pasa la solicitud tal cual
  return next(req);
};
*/