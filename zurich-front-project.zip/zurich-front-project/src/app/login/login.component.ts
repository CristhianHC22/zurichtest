import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';  
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { AuthService } from '../service/auth.service';

@Component({
  standalone: true,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'], // Si tienes estilos específicos para este componente
  imports: [
    CommonModule, 
    FormsModule,  // Asegúrate de que FormsModule esté importado
    ButtonModule, 
    InputTextModule, 
    PasswordModule
  ]
})
export class LoginComponent {
  username: string = '';
  password: string = '';

  constructor(private authService: AuthService,private router: Router) {}

  onSubmit() {
    this.authService.login(this.username, this.password).subscribe(
      (response) => {
        if (response.token) {
          localStorage.setItem('token', response.token);
          sessionStorage.setItem('autorization',response);
          if(response.rolId[0] === 2){
            this.router.navigate(['/customer']);
          }else{
            this.router.navigate(['/policies']);
          }

        } else {
          alert('Invalid credentials');
        }
      },
      (error) => {
        alert('Login failed');
      }
    );
  }
}
