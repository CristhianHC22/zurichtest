import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginatorModule } from 'primeng/paginator';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { CustomerService } from '../service/customer.service';
import { InputTextModule } from 'primeng/inputtext';
import { MessageService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { CalendarModule } from 'primeng/calendar';
import { FormsModule } from '@angular/forms';
import { PolizaService } from '../service/poliza.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-policy-list',
  standalone: true,
  templateUrl: './policy-list.component.html',
  imports: [
    CommonModule,
    PaginatorModule,
    TableModule,
    DialogModule,
    ButtonModule,
    InputTextModule,
    ToastModule,
    ConfirmDialogModule,
    CalendarModule,
    FormsModule
  ],
  providers: [MessageService]
})
export class PolicyListComponent implements OnInit {

  policys: any[] = [];
  totalRecords: number = 0;
  loading: boolean = false;


  estadoPoliza = [
    { label: 'Activa', value: 'ACTIVA' },
    { label: 'Cancelada', value: 'CANCELADA' }
  ];

  tiposPoliza = [
    { label: 'Vida', value: 'VIDA' },
    { label: 'Automovil', value: 'AUTOMOVIL' },
    { label: 'Salud', value: 'SALUD' },
    { label: 'Hogar', value: 'HOGAR' }
  ];

  // Definir la estructura de los criterios de búsqueda
  searchCriteria = {
    nombre: '',
    identificacion: '',
    email: ''
  };

  displayEditClientDialog: boolean = false;
  displayDeletePolicyDialog: boolean = false;
  selectedPolicy: any; // Policye seleccionado para eliminación
  isEditing: boolean = false; // Determina si estamos editando un policye
  clientForm = { email: '', telefono: '' };

  constructor(private clientService: CustomerService, 
    private policyService: PolizaService, 
    private messageService: MessageService,
    private cdr: ChangeDetectorRef,
    private router: Router) { }

  ngOnInit() {
    this.loadPolicys(0, 10);
    this.loadMyData()
  }

  loadMyData(){
    this.clientService.getByMyUser().subscribe(response => {
      console.log(response.email)

      // Actualiza las propiedades de clientForm directamente
      this.clientForm.email = response.email;
      this.clientForm.telefono = response.telefono;
      // Forzar la detección de cambios
      this.cdr.detectChanges();
    },
      (error) => {
        console.log(error);
        this.showErrorMessage('Error al actualizar el cliente', error.error.error.message); // Mostrar error si ocurre
      });
  }

  logout() {
    // Elimina los datos de la sesión (e.g., token de autenticación)
    localStorage.removeItem('accessToken');
    sessionStorage.clear(); // Si también usas sessionStorage

    // Redirige al usuario a la página de login
    this.router.navigate(['/login']);
  }


  loadPolicys(page: number, size: number) {
    this.loading = true;
    this.policyService.getPolicyUser(page, size).subscribe(response => {
      this.policys = response.list;
      this.totalRecords = response.meta.totalItems;
      this.loading = false;
    });
  }

  onPageChange(event: any) {
    const page = event.first / event.rows;
    const size = event.rows;
    this.loadPolicys(page, size);
  }

  confirmCancelPolicy(policy: any) {
    this.selectedPolicy = policy; // Guardar el policye seleccionado para eliminar
    this.displayDeletePolicyDialog = true; // Mostrar el modal de confirmación
  }

  cancelPolicy() {
    if (this.selectedPolicy) {
      this.policyService.updatePolicy(this.estadoPoliza[1].value, this.selectedPolicy.id).subscribe(
        () => {
          this.loadPolicys(0, 10);
          this.displayDeletePolicyDialog = false; // Cerrar el modal
          this.selectedPolicy = null; // Limpiar la selección
        },
        (error) => {
          this.displayDeletePolicyDialog = false; // Cerrar el modal
          this.selectedPolicy = null; // Limpiar la selección
          this.showErrorMessage('Error al eliminar el policye', error.error.message);
        }
      );
    }
  }


  showErrorMessage(summary: string, detail: string) {
    this.messageService.add({
      severity: 'error',
      summary: summary,
      detail: detail,
    });
  }

  showAddEditDialog() {
    this.clientForm = { email: '', telefono: '' }; // Limpiar el formulario
    this.displayEditClientDialog = true;
  }

  hideEditClientDialog() {
    this.displayEditClientDialog = false;
  }

  isFormValid(): boolean {
    return this.clientForm.email.trim() !== '' && this.clientForm.telefono.trim() !== '';
  }

  // Actualizar un cliente
  updateClient() {
    this.clientService.updateSelfClient(this.clientForm).subscribe(response => {
      this.hideEditClientDialog(); // Cerrar el modal
      this.loadMyData();
    },
      (error) => {
        console.log(error);
        this.showErrorMessage('Error al actualizar el cliente', error.error.error.message); // Mostrar error si ocurre
      });
  }
}
