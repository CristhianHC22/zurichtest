import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginatorModule } from 'primeng/paginator';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { CustomerService } from '../service/customer.service';
import 'primeng/resources/themes/lara-light-indigo/theme.css'; // Importar el tema de PrimeNG
import 'primeng/resources/primeng.min.css'; // Importar los estilos de PrimeNG
import { InputTextModule } from 'primeng/inputtext';
import { MessageService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { CalendarModule } from 'primeng/calendar';
import { FormsModule } from '@angular/forms';
import { PolizaService } from '../service/poliza.service';
import { Router } from '@angular/router';
import { TooltipModule } from 'primeng/tooltip';

@Component({
  selector: 'app-client-list',
  standalone: true,
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.scss'], // Si tienes estilos específicos para este componente
  imports: [
    CommonModule,
    PaginatorModule,
    TableModule,
    DialogModule,
    ButtonModule,
    InputTextModule,
    ToastModule,
    ConfirmDialogModule,
    CalendarModule,
    FormsModule,
    TooltipModule
  ],
  providers: [MessageService]
})
export class ClientListComponent implements OnInit {
  clients: any[] = [];
  totalRecords: number = 0;
  loading: boolean = false;


  estadoPoliza = [
    { label: 'Activa', value: 'ACTIVA' },
    { label: 'Cancelada', value: 'CANCELADA' }
  ];

  tiposPoliza = [
    { label: 'Vida', value: 'VIDA' },
    { label: 'Automovil', value: 'AUTOMOVIL' },
    { label: 'Salud', value: 'SALUD' },
    { label: 'Hogar', value: 'HOGAR' }
  ];

  // Definir la estructura de los criterios de búsqueda
  searchCriteria = {
    nombre: '',
    identificacion: '',
    email: ''
  };

  displayAddClientDialog: boolean = false;
  displayDeleteClientDialog: boolean = false;
  displayAddPolicyDialog: boolean = false;
  displayShowPolicies: boolean = false;
  selectedClient: any; // Cliente seleccionado para eliminación
  isEditing: boolean = false; // Determina si estamos editando un cliente
  clientForm = { nombre: '', email: '', telefono: '', identificacion: '' };
  polizaForm = { tipo: this.tiposPoliza[0].value, fechaInicio: new Date(), fechaFin: new Date(), montoAsegurado: 0, estado: this.estadoPoliza[0].value, clienteId: '' };

  tipoSearch=this.tiposPoliza[0].value;
  estadoSearch=this.estadoPoliza[0].value;
  fechaInicioSearch=new Date();
  fechaFinSearch=new Date();;

  policys: any[] = [];

  constructor(private clientService: CustomerService, private policyService: PolizaService, private messageService: MessageService,
      private router: Router) { }

  ngOnInit() {
    this.loadClients(0, 10);
    this.polizaForm.fechaFin.setFullYear(this.polizaForm.fechaInicio.getFullYear() + 1);
  }

  loadClients(page: number, size: number) {
    this.loading = true;
    this.clientService.getClients(this.searchCriteria, page, size).subscribe(response => {
      this.clients = response.list;
      this.totalRecords = response.meta.totalItems;
      this.loading = false;
    });
  }

  onPageChange(event: any) {
    const page = event.first / event.rows;
    const size = event.rows;
    this.loadClients(page, size);
  }

  // Mostrar el modal para agregar un cliente
  showAddClientDialog() {
    this.isEditing = false; // Modo agregar
    this.clientForm = { nombre: '', email: '', telefono: '', identificacion: '' }; // Limpiar el formulario
    this.displayAddClientDialog = true;
  }

  // Mostrar el modal para agregar un cliente
  showAddPolicyDialog(client: any) {
    this.polizaForm = { tipo: this.tiposPoliza[0].value, fechaInicio: new Date(), fechaFin: new Date(), montoAsegurado: 0, estado: this.estadoPoliza[0].value, clienteId: client.id };
    this.displayAddPolicyDialog = true;
  }

  // Mostrar el modal para editar un cliente
  showEditClientDialog(client: any) {
    this.isEditing = true; // Modo editar
    this.clientForm = { ...client }; // Cargar los datos del cliente en el formulario
    this.displayAddClientDialog = true;
  }

  confirmDeleteClient(client: any) {
    this.selectedClient = client; // Guardar el cliente seleccionado para eliminar
    this.displayDeleteClientDialog = true; // Mostrar el modal de confirmación
  }

  showSearchPolicyDialog() {
    this.displayShowPolicies = true;
  }

  // Ocultar el modal
  hideAddClientDialog() {
    this.displayAddClientDialog = false;
  }

  hideAddPolicyDialog() {
    this.displayAddPolicyDialog = false;
  }

  // Guardar un nuevo cliente
  saveClient() {
    this.clientService.addClient(this.clientForm).subscribe(response => {
      this.loadClients(0, 10); // Recargar la lista de clientes
      this.hideAddClientDialog(); // Cerrar el modal
    },
      (error) => {
        this.loading = false;
        this.showErrorMessage('Error al cargar los clientes', error.error.message); // Mostrar error si ocurre
      });
  }

  // Guardar un nuevo cliente
  savePolicy() {
    this.policyService.addPoliza(this.polizaForm).subscribe(response => {
      this.loadClients(0, 10); // Recargar la lista de clientes
      this.hideAddPolicyDialog(); // Cerrar el modal
      this.messageService.add({
        severity: 'success',
        summary: 'Poliza Creada',
        detail: 'Poliza creada con exito',
      });
    },
      (error) => {
        this.loading = false;
        this.showErrorMessage('Error al cargar los clientes', error.error.message); // Mostrar error si ocurre
      });
  }

  // Actualizar un cliente
  updateClient() {
    console.log(this.polizaForm.tipo);
    this.clientService.updateClient(this.clientForm).subscribe(response => {
      this.loadClients(0, 10); // Recargar la lista de clientes
      this.hideAddClientDialog(); // Cerrar el modal
    },
      (error) => {
        console.log(error);
        this.showErrorMessage('Error al actualizar el cliente', error.error.error.message); // Mostrar error si ocurre
      });
  }

  // Validación del formulario
  isFormValid(): boolean {
    return this.clientForm.nombre.trim() !== '' && this.clientForm.email.trim() !== '' && this.clientForm.telefono.trim() !== '' && this.clientForm.identificacion.trim() !== '';
  }

  isPolicyValid(): boolean {
    return this.polizaForm.tipo.trim() !== '';
  }

  showErrorMessage(summary: string, detail: string) {
    this.messageService.add({
      severity: 'error',
      summary: summary,
      detail: detail,
    });
  }

  deleteClient() {
    if (this.selectedClient) {
      this.clientService.deleteClient(this.selectedClient.id).subscribe(
        () => {
          this.loadClients(0, 10);
          this.displayDeleteClientDialog = false; // Cerrar el modal
          this.selectedClient = null; // Limpiar la selección
        },
        (error) => {
          this.displayDeleteClientDialog = false; // Cerrar el modal
          this.selectedClient = null; // Limpiar la selección
          this.showErrorMessage('Error al eliminar el cliente', error.error.message);
        }
      );
    }
  }

  onSearch() {
    this.loading = true; // Iniciar carga
    this.loadClients(0, 10);
    this.loading = false; // Finalizamos la carga
    this.searchCriteria = {
      nombre: '',
      identificacion: '',
      email: ''
    };
  }

  logout() {
    // Elimina los datos de la sesión (e.g., token de autenticación)
    localStorage.removeItem('accessToken');
    sessionStorage.clear(); // Si también usas sessionStorage

    // Redirige al usuario a la página de login
    this.router.navigate(['/login']);
  }

  onSearchPolicy(){
    this.policyService.getPolicies({tipo:this.tipoSearch,estado:this.estadoSearch,fechaInicio:this.fechaInicioSearch,fechaFin:this.fechaFinSearch}, 0, 50).subscribe(response => {
      console.log(response.list)
      this.policys = response.list;
    });
  }

}
