import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PolizaService {

  private apiUrl = 'https://zurich-server-api-dcac179948c8.herokuapp.com/polizas';

  constructor(private http: HttpClient) { }

  addPoliza(poliza: any): Observable<any> {

    const token = localStorage.getItem('token');
    // Configurar los headers de la solicitud con el token (si está presente)
    const headers = token ? new HttpHeaders().set('Authorization', `Bearer ${token}`) : new HttpHeaders();


    return this.http.post(this.apiUrl, poliza, { headers, withCredentials: true });
  }

  getPolicyUser(page: number, size: number): Observable<any> {
    const url = `${this.apiUrl}/usuario`;
    const token = localStorage.getItem('token');
    // Configurar los headers de la solicitud con el token (si está presente)
    const headers = token ? new HttpHeaders().set('Authorization', `Bearer ${token}`) : new HttpHeaders();

    let params = new HttpParams()
      .set('pagina', page.toString())
      .set('limite', size.toString());

    return this.http.get<any>(url, { headers, params, withCredentials: true });
  }

  updatePolicy(estado: any, polizaId: any): Observable<any> {
    const url = `${this.apiUrl}/${polizaId}`;

    const token = localStorage.getItem('token');
    // Configurar los headers de la solicitud con el token (si está presente)
    const headers = token ? new HttpHeaders().set('Authorization', `Bearer ${token}`) : new HttpHeaders();


    return this.http.patch(url, { estado }, { headers, withCredentials: true });
  }

  getPolicies(criteria: any, page: number, size: number): Observable<any> {

    const token = localStorage.getItem('token');
    // Configurar los headers de la solicitud con el token (si está presente)
    const headers = token ? new HttpHeaders().set('Authorization', `Bearer ${token}`) : new HttpHeaders();

    let params = new HttpParams()
      .set('pagina', page.toString())
      .set('limite', size.toString());

    if (criteria.tipo) {
      params = params.set('tipo', criteria.tipo);
    }
    if (criteria.estado) {
      params = params.set('estado', criteria.estado);
    }
    if (criteria.fechaInicio) {
      params = params.set('fechaInicio', criteria.fechaInicio.toISOString());
    }
    if (criteria.fechaFin) {
      params = params.set('fechaFin', criteria.fechaFin.toISOString());
    }


    return this.http.get<any>(this.apiUrl, { headers, params, withCredentials: true });
  }
}