import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CustomerService {
  private apiUrl = 'https://zurich-server-api-dcac179948c8.herokuapp.com/clientes';

  constructor(private http: HttpClient) { }

  getClients(criteria: any, page: number, size: number): Observable<any> {

    const token = localStorage.getItem('token');
    // Configurar los headers de la solicitud con el token (si está presente)
    const headers = token ? new HttpHeaders().set('Authorization', `Bearer ${token}`) : new HttpHeaders();

    let params = new HttpParams()
      .set('pagina', page.toString())
      .set('limite', size.toString());

    if (criteria.nombre) {
      params = params.set('nombre', criteria.nombre);
    }
    if (criteria.identificacion) {
      params = params.set('identificacion', criteria.identificacion);
    }
    if (criteria.email) {
      params = params.set('email', criteria.email);
    }


    return this.http.get<any>(this.apiUrl, { headers, params, withCredentials: true });
  }

  getByMyUser(): Observable<any> {
    const url = `${this.apiUrl}/usuario`;
    const token = localStorage.getItem('token');
    // Configurar los headers de la solicitud con el token (si está presente)
    const headers = token ? new HttpHeaders().set('Authorization', `Bearer ${token}`) : new HttpHeaders();

    return this.http.get<any>(url, { headers, withCredentials: true });
  }

  addClient(cliente: any): Observable<any> {

    const token = localStorage.getItem('token');
    // Configurar los headers de la solicitud con el token (si está presente)
    const headers = token ? new HttpHeaders().set('Authorization', `Bearer ${token}`) : new HttpHeaders();


    return this.http.post(this.apiUrl, cliente, { headers, withCredentials: true });
  }

  updateClient(cliente: any): Observable<any> {
    const url = `${this.apiUrl}/${cliente.id}`;

    const token = localStorage.getItem('token');
    // Configurar los headers de la solicitud con el token (si está presente)
    const headers = token ? new HttpHeaders().set('Authorization', `Bearer ${token}`) : new HttpHeaders();


    return this.http.patch(url, { email: cliente.email, telefono: cliente.telefono }, { headers, withCredentials: true });
  }

  updateSelfClient(cliente: any): Observable<any> {
    const url = `${this.apiUrl}/usuario`;

    const token = localStorage.getItem('token');
    // Configurar los headers de la solicitud con el token (si está presente)
    const headers = token ? new HttpHeaders().set('Authorization', `Bearer ${token}`) : new HttpHeaders();


    return this.http.put(url, { email: cliente.email, telefono: cliente.telefono }, { headers, withCredentials: true });
  }

  deleteClient(clienteId: any): Observable<any> {
    const url = `${this.apiUrl}/${clienteId}`;

    const token = localStorage.getItem('token');
    // Configurar los headers de la solicitud con el token (si está presente)
    const headers = token ? new HttpHeaders().set('Authorization', `Bearer ${token}`) : new HttpHeaders();


    return this.http.delete(url, { headers, withCredentials: true });
  }
}
