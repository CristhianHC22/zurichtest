
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { Route } from '@angular/router';
import { ClientListComponent } from './client-list/client-list.component';
import { PolicyListComponent } from './policy-list/policy-list.component';

export const routes: Route[] = [
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'customer', component: ClientListComponent },
  { path: 'policies', component: PolicyListComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' }  // Redirige a login por defecto
];
