import { bootstrapApplication } from '@angular/platform-browser';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
//import { authInterceptor } from './app/interceptor/auth.interceptor';
import { AppComponent } from './app/app.component';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { importProvidersFrom } from '@angular/core';
import { routes } from './app/app.routes';

bootstrapApplication(AppComponent, {
  providers: [
    importProvidersFrom(RouterModule.forRoot(routes), HttpClientModule, BrowserAnimationsModule),
   // { provide: HTTP_INTERCEPTORS, useValue: authInterceptor, multi: true }
  ]
})
  .catch(err => console.error(err));
