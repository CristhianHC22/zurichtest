import {
  Tooltip,
  TooltipModule
} from "./chunk-MSZE55HP.js";
import "./chunk-3SQF7L7O.js";
import "./chunk-Z4RYF7KA.js";
import "./chunk-355YGYZD.js";
import "./chunk-YNLWGVCA.js";
import "./chunk-SU2WE4RP.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map
