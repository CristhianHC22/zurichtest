import {
  InputText,
  InputTextModule
} from "./chunk-X3IP2FCG.js";
import "./chunk-2VPFXDPV.js";
import "./chunk-355YGYZD.js";
import "./chunk-YNLWGVCA.js";
import "./chunk-SU2WE4RP.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
