import {
  INPUTNUMBER_VALUE_ACCESSOR,
  InputNumber,
  InputNumberModule
} from "./chunk-4CNBE5UV.js";
import "./chunk-X3IP2FCG.js";
import "./chunk-6THTVNIH.js";
import "./chunk-2VPFXDPV.js";
import "./chunk-3BANCRCW.js";
import "./chunk-RLXDGSWF.js";
import "./chunk-OT6KADS5.js";
import "./chunk-BKZWOI7I.js";
import "./chunk-3SQF7L7O.js";
import "./chunk-Z4RYF7KA.js";
import "./chunk-355YGYZD.js";
import "./chunk-YNLWGVCA.js";
import "./chunk-SU2WE4RP.js";
export {
  INPUTNUMBER_VALUE_ACCESSOR,
  InputNumber,
  InputNumberModule
};
//# sourceMappingURL=primeng_inputnumber.js.map
