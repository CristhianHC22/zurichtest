import {
  Paginator,
  PaginatorModule
} from "./chunk-X7XWGLEI.js";
import "./chunk-GS7HMODY.js";
import "./chunk-U75FJJAE.js";
import "./chunk-MSZE55HP.js";
import "./chunk-4CNBE5UV.js";
import "./chunk-X3IP2FCG.js";
import "./chunk-6THTVNIH.js";
import "./chunk-EKIW5Y6P.js";
import "./chunk-2VPFXDPV.js";
import "./chunk-3BANCRCW.js";
import "./chunk-RLXDGSWF.js";
import "./chunk-OT6KADS5.js";
import "./chunk-BKZWOI7I.js";
import "./chunk-3SQF7L7O.js";
import "./chunk-Z4RYF7KA.js";
import "./chunk-355YGYZD.js";
import "./chunk-YNLWGVCA.js";
import "./chunk-SU2WE4RP.js";
export {
  Paginator,
  PaginatorModule
};
//# sourceMappingURL=primeng_paginator.js.map
