import {
  Tooltip,
  TooltipModule
} from "./chunk-LPHH5XCW.js";
import "./chunk-IS2NJ2KB.js";
import "./chunk-YB7WTEJX.js";
import "./chunk-LC63JU7F.js";
import "./chunk-SXHOZHTL.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map
