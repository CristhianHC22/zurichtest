import {
  INPUTNUMBER_VALUE_ACCESSOR,
  InputNumber,
  InputNumberModule
} from "./chunk-WYJ5Q5F3.js";
import "./chunk-OHKXGLDU.js";
import "./chunk-MMJD6NYL.js";
import "./chunk-WAU2QFQN.js";
import "./chunk-6UWOUDTU.js";
import "./chunk-MVK62XNF.js";
import "./chunk-LVJ2ZDK5.js";
import "./chunk-RJHN5L3D.js";
import "./chunk-IS2NJ2KB.js";
import "./chunk-YB7WTEJX.js";
import "./chunk-LC63JU7F.js";
import "./chunk-SXHOZHTL.js";
export {
  INPUTNUMBER_VALUE_ACCESSOR,
  InputNumber,
  InputNumberModule
};
//# sourceMappingURL=primeng_inputnumber.js.map
