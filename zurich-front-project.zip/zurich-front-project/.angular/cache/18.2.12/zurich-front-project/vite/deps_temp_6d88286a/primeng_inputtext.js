import {
  InputText,
  InputTextModule
} from "./chunk-OHKXGLDU.js";
import "./chunk-MMJD6NYL.js";
import "./chunk-LC63JU7F.js";
import "./chunk-SXHOZHTL.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
