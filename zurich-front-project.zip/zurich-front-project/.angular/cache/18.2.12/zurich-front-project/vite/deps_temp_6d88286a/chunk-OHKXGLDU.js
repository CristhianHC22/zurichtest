import {
  NgModel
} from "./chunk-MMJD6NYL.js";
import {
  CommonModule
} from "./chunk-LC63JU7F.js";
import {
  ChangeDetectorRef,
  Directive,
  ElementRef,
  HostListener,
  NgModule,
  Optional,
  setClassMetadata,
  ɵɵclassProp,
  ɵɵdefineDirective,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵlistener
} from "./chunk-SXHOZHTL.js";

// node_modules/primeng/fesm2020/primeng-inputtext.mjs
var InputText = class {
  constructor(el, ngModel, cd) {
    this.el = el;
    this.ngModel = ngModel;
    this.cd = cd;
  }
  ngAfterViewInit() {
    this.updateFilledState();
    this.cd.detectChanges();
  }
  ngDoCheck() {
    this.updateFilledState();
  }
  onInput(e) {
    this.updateFilledState();
  }
  updateFilledState() {
    this.filled = this.el.nativeElement.value && this.el.nativeElement.value.length || this.ngModel && this.ngModel.model;
  }
};
InputText.ɵfac = function InputText_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || InputText)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(NgModel, 8), ɵɵdirectiveInject(ChangeDetectorRef));
};
InputText.ɵdir = ɵɵdefineDirective({
  type: InputText,
  selectors: [["", "pInputText", ""]],
  hostAttrs: [1, "p-inputtext", "p-component", "p-element"],
  hostVars: 2,
  hostBindings: function InputText_HostBindings(rf, ctx) {
    if (rf & 1) {
      ɵɵlistener("input", function InputText_input_HostBindingHandler($event) {
        return ctx.onInput($event);
      });
    }
    if (rf & 2) {
      ɵɵclassProp("p-filled", ctx.filled);
    }
  }
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(InputText, [{
    type: Directive,
    args: [{
      selector: "[pInputText]",
      host: {
        class: "p-inputtext p-component p-element",
        "[class.p-filled]": "filled"
      }
    }]
  }], function() {
    return [{
      type: ElementRef
    }, {
      type: NgModel,
      decorators: [{
        type: Optional
      }]
    }, {
      type: ChangeDetectorRef
    }];
  }, {
    onInput: [{
      type: HostListener,
      args: ["input", ["$event"]]
    }]
  });
})();
var InputTextModule = class {
};
InputTextModule.ɵfac = function InputTextModule_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || InputTextModule)();
};
InputTextModule.ɵmod = ɵɵdefineNgModule({
  type: InputTextModule,
  declarations: [InputText],
  imports: [CommonModule],
  exports: [InputText]
});
InputTextModule.ɵinj = ɵɵdefineInjector({
  imports: [CommonModule]
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(InputTextModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule],
      exports: [InputText],
      declarations: [InputText]
    }]
  }], null, null);
})();

export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=chunk-OHKXGLDU.js.map
