# Proyecto Angular 18.2 con PrimeNG

Este es un proyecto de ejemplo utilizando **Angular 18.2** y **PrimeNG** para crear interfaces ricas y modernas. PrimeNG es una colección de componentes UI con muchas características como tablas, botones, calendarios, etc.

## Requisitos

Antes de comenzar, asegúrate de tener instaladas las siguientes herramientas:

- **Node.js** (recomendado: versión 16 o superior)
- **npm** (viene con Node.js)
- **Angular CLI** (si no lo tienes instalado, puedes hacerlo con el comando `npm install -g @angular/cli`)

## Instalación

### 1. Clonar el repositorio

Primero, clona el repositorio del proyecto en tu máquina local:

```bash
git clone https://github.com/tu-usuario/tu-proyecto-angular.git
cd tu-proyecto-angular

### 2. Instalar dependencias

npm install

### 3. Configuración de PrimeNG

npm install primeng primeicons

### 4.  Ejecutar el proyecto

ng serve





